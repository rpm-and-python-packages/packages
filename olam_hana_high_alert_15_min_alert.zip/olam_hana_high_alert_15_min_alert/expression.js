(function()
{
	
	var code_bucket = response;  					 //Your Response Bucket or you can use "response",type=object
        ${tmp.app} ="";   						//Service Now Application  ,type==String
        ${tmp.issue} ="";     					//Issue ,type==String
        ${tmp.upstream} ="";   					//Upstream Application ,type==String
        ${tmp.downstream} ="";  			   //Downstteam Application ,type==String
        ${tmp.service_path} ="";   			   //Business Service Impact ,type==String
        ${tmp.severity} = "Sev1";   					//(Sev1,Sev2,Sev3,Sev4) ,type==String
        ${tmp.token} ="907484899:AAF2bEhn3dDBBW-nQBAJanhiBXzNP22FtcI";     					//telegram bot token ,type==String
        ${tmp.chatid} ="-321565096";    					//Telegram chat id ,type==String
	${tmp.token} = "1091136832:AAEWdWZ1DYTlVDS8vhHnAB-RQrgJf6-cbKc"
	${tmp.chatid} = "-289475056"

 	//SERVICE NOW HOSTS
   	${tmp.ip1} ="172.29.8.27";   						//service now ip1,type=string
 //     ${tmp.ip2} ="10.175.6.83";    						//service now ip2,type=string
        ${tmp.ip3} ="10.175.6.29";    						//service now ip3,type=string
	var dev_token = "1091136832:AAEWdWZ1DYTlVDS8vhHnAB-RQrgJf6-cbKc";
	var dev_chatid = "-289475056"
	var prod_token = "907484899:AAF2bEhn3dDBBW-nQBAJanhiBXzNP22FtcI";
 	var prod_chatid = "-321565096"
 	var domain=".olamdomain"	
      	var records=code_bucket.hits.hits;
	console.log("response print-->",records);
	//process.exit(1);
	//Your Actual expression starts here 
	records.forEach(function(db_value){
		var date =new Date(/*Your Date Field*/).toString(); //configure date parameter.use "Date.now()" if your response does not contain any.
		${tmp.alert_date} =date.slice(0, 24);
     //		${tmp.token}= dev_token ;
     //         ${tmp.chatid}=dev_chatid ;
		${tmp.token}= prod_token ;
                ${tmp.chatid}=prod_chatid ;
		${tmp.host}=db_value["_source"]["hostname"];
			if((db_value["_source"]["alert_id"]!= 20)||(db_value["_source"]["alert_id"]!= 65)||(db_value["_source"]["alert_id"]!= 62)){	
                        if (db_value["_source"]["alert_type"]=='start' ) {
                        	 ${tmp.telegram_message} = "<b>Olam  Alert:</b>" + "HANA high alert received in last 15 min for" + "\n\n<b>Alert Name:</b>"+db_value["_source"]["alert_name"]+"\n\n" + "<b>Host: </b>" + db_value["_source"]["hostname"] + "\n" +  "<b>Aler ID: </b>"+ db_value["_source"]["alert_id"]+"\n"+"<b>Alert Raiting: </b>"+db_value["_source"]["alert_rating"]+"\n"+"<b>DB:</b>"+db_value["_source"]["db"] +"\n"+"<b>Instance:</b>"+db_value["_source"]["instance"]+"\n" + "<b>Upstream: </b>" + "N/A" + "\n" + "<b>Downstream: </b>" + "N/A" +"\n" + "<b>Severity: </b>" + "Major" + "\n"  + "<b>Application Name: </b>" + "N/A";

				${tmp.noc_short_text}= "HANA high alert received in last 15 min for Host: " + db_value["_source"]["hostname"] + " Aler ID: "+ db_value["_source"]["alert_id"]+" DB: "+db_value["_source"]["db"];

				${tmp.noc_message}=  "Olam  Alert: HANA high alert received in last 15 min for Alert Name: "+db_value["_source"]["alert_name"]+" Host: " +  db_value["_source"]["hostname"] + " Aler ID: "+ db_value["_source"]["alert_id"] +" Alert Raiting: "+db_value["_source"]["alert_rating"] + " IP:"+ db_value['_source']['server_ip']+" DB: "+db_value["_source"]["db"]+" Instance: "+db_value["_source"]["instance"] +" Application Name: "+"N/A"+ " Upstream: N/A Downstream: N/A Severity: Major";
                             	${ALERT_ID} ="hana_high_alert"+db_value['_source']['server_ip']+db_value["_source"]["hostname"]+db_value["_source"]["db"]+db_value["_source"]["alert_id"];
                              	alertUp();
                         }
                         else {
                               
				 ${tmp.telegram_message} = "<b>Olam  Alert:</b>" + "HANA high alert received in last 15 min for" + "\n\n<b>Alert Name:</b>"+db_value["_source"]["alert_name"]+"\n\n" + "<b>Host: </b>" + db_value["_source"]["hostname"] + "\n" +  "<b>Aler ID: </b>"+ db_value["_source"]["alert_id"]+"\n"+"<b>Alert Raiting: </b>"+db_value["_source"]["alert_rating"]+"\n"+"<b>DB:</b>"+db_value["_source"]["db"] +"\n"+"<b>Instance:</b>"+db_value["_source"]["instance"]+"\n" + "<b>Upstream: </b>" + "N/A" + "\n" + "<b>Downstream: </b>" + "N/A" +"\n" + "<b>Severity: </b>" + "Major" + "\n"  + "<b>Application Name: </b>" + "N/A";

                                ${tmp.noc_short_text}= "HANA high alert received in last 15 min for Host: " + db_value["_source"]["hostname"] + " Aler ID: "+ db_value["_source"]["alert_id"]+" DB: "+db_value["_source"]["db"];

                                ${tmp.noc_message}=  "Olam  Alert: HANA high alert received in last 15 min for Alert Name: "+db_value["_source"]["alert_name"]+" Host: " +  db_value["_source"]["hostname"] + " Aler ID: "+ db_value["_source"]["alert_id"] +" Alert Raiting: "+db_value["_source"]["alert_rating"] + " IP:"+ db_value['_source']['server_ip']+" DB: "+db_value["_source"]["db"]+" Instance: "+db_value["_source"]["instance"] +" Application Name: "+"N/A"+ " Upstream: N/A Downstream: N/A Severity: Major";
                                ${ALERT_ID} ="hana_high_alert"+db_value['_source']['server_ip']+db_value["_source"]["hostname"]+db_value["_source"]["db"]+db_value["_source"]["alert_id"];
				alertDown();
                         }
		}

                 

	
        });

}
)()


