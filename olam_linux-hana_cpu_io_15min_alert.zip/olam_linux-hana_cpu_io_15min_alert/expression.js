(function()
{
	
	var code_bucket = response;  					 //Your Response Bucket or you can use "response",type=object
        ${tmp.app} ="";   						//Service Now Application  ,type==String
        ${tmp.issue} ="";     					//Issue ,type==String
        ${tmp.upstream} ="";   					//Upstream Application ,type==String
        ${tmp.downstream} ="";  			   //Downstteam Application ,type==String
        ${tmp.service_path} ="";   			   //Business Service Impact ,type==String
        ${tmp.severity} = "Sev2";   					//(Sev1,Sev2,Sev3,Sev4) ,type==String
	${tmp.cpu_usage_iowait_threshold}=0.80   				//Threshold according to your usecase ,type=number
//        ${tmp.token} ="907484899:AAF2bEhn3dDBBW-nQBAJanhiBXzNP22FtcI";     					//telegram bot token ,type==String
  //      ${tmp.chatid} ="-321565096";    					//Telegram chat id ,type==String
//	${tmp.token} = "1091136832:AAEWdWZ1DYTlVDS8vhHnAB-RQrgJf6-cbKc"
//	${tmp.chatid} = "-289475056"

 	//SERVICE NOW HOSTS
     	${tmp.ip1} ="172.29.8.27";   						//service now ip1,type=string
        ${tmp.ip2} ="10.175.6.83";    						//service now ip2,type=string
        ${tmp.ip3} ="10.175.6.29";    						//service now ip3,type=string
	var dev_token = "1091136832:AAEWdWZ1DYTlVDS8vhHnAB-RQrgJf6-cbKc";
	var dev_chatid = "-289475056"
	var prod_token = "907484899:AAF2bEhn3dDBBW-nQBAJanhiBXzNP22FtcI";
 	var prod_chatid = "-321565096"
        var env_token = "1575784127:AAHApkm2VeWEhd2bsj4rMmVXqSrHHxg0TXg";
	var env_chatid = "-414426145"
	var domain=".olam.net"	
	
   	//Your Actual expression starts here 
	code_bucket.forEach(function(current_cpu){
		var date =new Date(/*Your Date Field*/).toString(); //configure date parameter.use "Date.now()" if your response does not contain any.
		${tmp.alert_date} =date.slice(0, 24);
		 var env = current_cpu['Environment'] !== "" ? current_cpu['Environment'].toLowerCase() : "";
            //    ${tmp.token}= env == "production" ? prod_token  : dev_token ;
	        ${tmp.token}= env == "production" ? env_token  : dev_token ;
          //      ${tmp.chatid}= env == "production" ? prod_chatid : dev_chatid ;
                ${tmp.chatid}= env == "production" ? env_chatid : dev_chatid ;
		${tmp.host}=current_cpu.host;	
		 if (current_cpu.usage_iowait){
                 	current_cpu_usage_iowait = (current_cpu.usage_iowait/100).toFixed(2);
                        if (current_cpu_usage_iowait >= ${tmp.cpu_usage_iowait_threshold}){
                        	 ${tmp.telegram_message} = "<b>Olam  Alert:</b>" + "Hana Cpu utilization for usage iowait in last 30 minutes breach the threshold" + "\n\n" + "<b>Threshold: </b>" + ${tmp.cpu_usage_iowait_threshold}*100 + "\n\n" +  "<b>Current Threshold: </b>"+ (current_cpu.usage_iowait).toFixed(2)  +"\n" +"<b>Host: </b>"+ current_cpu.host +"\n" + "<b>Upstream: </b>" + "N/A" + "\n" + "<b>Downstream: </b>" + "N/A" +"\n" + "<b>Severity: </b>" + "Critical" + "\n" + "<b>Business unit: </b>" + current_cpu['Business unit'] + "\n" + "<b>Application Name: </b>" + current_cpu['Application Name'] + "<b>Environment: </b>" + current_cpu['Environment'];
			
				${tmp.noc_short_text}= "Hana Cpu utilization for usage iowait in last 30 minutes breach the threshold. Threshold: " + ${tmp.cpu_usage_iowait_threshold}*100 + " Current Threshold: "+ (current_cpu.usage_iowait).toFixed(2) ;		
	
                		  ${tmp.noc_message}=  "Olam  Alert: Hana Cpu utilization for usage iowait in last 30 minutes breach the threshold. Threshold: " + ${tmp.cpu_usage_iowait_threshold}*100 + " Current Threshold: "+ (current_cpu.usage_iowait).toFixed(2)  +" Host:"+ current_cpu.host + " IP:"+ current_cpu['IP'] + " Upstream: N/A Downstream: N/A Severity: Critical Business unit: " + current_cpu['Business unit'] + "Application Name: " + current_cpu['Application Name'] + " Environment: " + current_cpu['Environment'];	
                             	${ALERT_ID} ="hana_cpu_usage_iowait"+current_cpu.host;
                                alertUp();
                        }
                        else{
                        	 ${tmp.telegram_message} = "<b>Olam  Alert:</b>" + "Hana Cpu utilization for usage iowait in last 30 minutes is in  threshold" + "\n\n" + "<b>Threshold: </b>" + ${tmp.cpu_usage_iowait_threshold}*100 + "\n\n"  +  "<b>Current Threshold: </b>"+ (current_cpu.usage_iowait).toFixed(2)  +"\n"  +"<b>Host: </b>"+ current_cpu.host +"\n" + "<b>Upstream: </b>" + "N/A" + "\n" + "<b>Downstream: </b>" + "N/A" +"\n" + "<b>Severity: </b>" + "Critical" + "\n" + "<b>Business unit: </b>" + current_cpu['Business unit'] + "\n" + "<b>Application Name: </b>" + current_cpu['Application Name'] + "<b>Environment: </b>" + current_cpu['Environment'];

				 ${tmp.noc_short_text}="Hana Cpu utilization for usage iowait in last 30 minutes is in  threshold. Threshold: " + ${tmp.cpu_usage_iowait_threshold}*100 + " Current Threshold: "+ (current_cpu.usage_iowait).toFixed(2) ;				

                        	 ${tmp.noc_message}=  "Olam  Alert: Hana Cpu utilization for usage iowait in last 30 minutes is in  threshold. Threshold: " + ${tmp.cpu_usage_iowait_threshold}*100 + " Current Threshold: "+ (current_cpu.usage_iowait).toFixed(2)  +" Host:"+ current_cpu.host + " IP:"+ current_cpu['IP'] + " Upstream: N/A Downstream: N/A Severity: Critical Business unit: " + current_cpu['Business unit'] + "Application Name: " + current_cpu['Application Name'] + " Environment: " + current_cpu['Environment'];
                                ${ALERT_ID} ="hana_cpu_usage_iowait"+current_cpu.host;
                                alertDown();
                        }
                 }
		

	
        });

}
)()


